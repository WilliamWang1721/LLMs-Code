# LLMs Code

<div align="center">

```
██╗     ██╗     ███╗   ███╗ ███████╗      ██████╗ ██████╗ ██████╗ ███████╗
██║     ██║     ████╗ ████║ ██╔════╝     ██╔════╝██╔═══██╗██╔══██╗██╔════╝
██║     ██║     ██╔████╔██║ ███████╗     ██║     ██║   ██║██║  ██║█████╗  
██║     ██║     ██║╚██╔╝██║ ╚════██║     ██║     ██║   ██║██║  ██║██╔══╝  
███████╗███████╗██║ ╚═╝ ██║ ███████║     ╚██████╗╚██████╔╝██████╔╝███████╗
╚══════╝╚══════╝╚═╝     ╚═╝ ╚══════╝      ╚═════╝ ╚═════╝ ╚═════╝ ╚══════╝
```

一个支持多种大语言模型的命令行工具，帮助开发者提高编码效率

[![License](https://img.shields.io/badge/license-Apache--2.0-blue.svg)](LICENSE)
[![Version](https://img.shields.io/badge/version-0.1.12-brightgreen.svg)](https://github.com/yourusername/llms-code)

</div>

> **注意**: LLMs Code 是在 [Google Gemini CLI](https://github.com/google-gemini/gemini-cli) 的基础上扩展开发的，增加了多模型适配器架构和更多LLM提供商的支持。特此感谢Google Gemini团队的开源贡献。

## 简介

LLMs Code 是一个命令行工具，允许开发者与多种大语言模型（LLM）进行交互，以提高编码效率。它支持多种LLM提供商，包括OpenAI、Anthropic、Google Gemini、DeepSeek、KIMI等，并提供统一的接口。

主要特点：

- 🚀 支持多种LLM提供商：OpenAI、Anthropic、Google Gemini、DeepSeek、KIMI等
- 🔄 适配器模式：统一接口，轻松切换不同的模型
- 🌐 国际化支持：支持多语言界面
- 💬 交互式CLI：提供友好的命令行交互界面
- ⚙️ 灵活配置：通过YAML文件进行配置，支持环境变量

## 安装

### 全局安装

```bash
npm install -g llms-code
```

安装完成后，您可以直接在终端中使用 `llms` 或 `llms-code` 命令启动程序：

```bash
# 以下两个命令效果相同
llms
llms-code
```

### 从源代码安装

```bash
git clone https://github.com/yourusername/llms-code.git
cd llms-code
npm install
npm run build
npm link
```

## 快速开始

### 配置

首次运行时，LLMs Code会引导您设置API密钥和默认模型。您也可以手动创建配置文件：

   ```bash
mkdir -p ~/.config/llms-code
   ```

创建`~/.config/llms-code/config.yaml`文件：

```yaml
# LLMs Code 配置文件
language: zh-CN  # 'en' 或 'zh-CN'

# 默认模型
default_model: gpt-4o

# 模型配置列表
models:
  - name: gpt-4o
    provider: openai
    api_key: env:OPENAI_API_KEY
    
  - name: claude-3-opus
    provider: anthropic
    api_key: env:ANTHROPIC_API_KEY
    
  - name: gemini-1.5-pro
    provider: gemini
    api_key: env:GEMINI_API_KEY
    
  - name: deepseek-coder
    provider: deepseek
    api_key: env:DEEPSEEK_API_KEY
    
  - name: kimi-chat
    provider: kimi
    api_key: env:KIMI_API_KEY
```

### 使用

启动交互式CLI：

```bash
llms-code chat
```

在交互式CLI中，您可以使用以下命令：

- `/help` - 显示帮助信息
- `/models` - 列出可用模型
- `/model <名称>` - 切换到指定模型
- `/clear` - 清除对话历史
- `/lang` - 更改语言
- `/exit` - 退出程序

## 支持的模型

| 提供商 | 支持的模型 |
|-------|-----------|
| OpenAI | gpt-4o, gpt-4-turbo, gpt-3.5-turbo, ... |
| Anthropic | claude-3-opus, claude-3-sonnet, claude-3-haiku, ... |
| Google | gemini-1.5-pro, gemini-1.5-flash, ... |
| DeepSeek | deepseek-coder, deepseek-chat, ... |
| KIMI | kimi-chat, ... |

## 开发

### 项目结构

```
llms-code/
├── packages/
│   ├── core/          # 核心库，包含适配器和API调用逻辑
│   ├── cli/           # 命令行界面
│   └── common/        # 共享工具和类型
├── examples/          # 示例代码
└── scripts/           # 构建和开发脚本
```

### 构建

```bash
npm run build
```

### 测试

```bash
npm test
```

## 贡献

欢迎贡献！请查看[贡献指南](CONTRIBUTING.md)了解如何参与。

## 许可证

本项目采用 [Apache 2.0 许可证](LICENSE)。
