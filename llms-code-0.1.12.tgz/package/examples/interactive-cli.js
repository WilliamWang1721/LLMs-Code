#!/usr/bin/env node

/**
 * LLMs Code 交互式 CLI
 * 
 * 这个脚本提供了一个交互式命令行界面，允许用户选择模型、输入问题并获取回答。
 * 使用方法：
 *   node interactive-cli.js
 */

import readline from 'node:readline/promises';
import { stdin as input, stdout as output } from 'node:process';
import { AdapterManager, AdapterContentGenerator } from '../packages/core/dist/index.js';

// 创建 readline 接口
const rl = readline.createInterface({ input, output });

// ANSI 颜色代码
const colors = {
  reset: '\x1b[0m',
  bright: '\x1b[1m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  cyan: '\x1b[36m',
};

// 打印带颜色的文本
function colorText(text, color) {
  return `${colors[color]}${text}${colors.reset}`;
}

// 打印带颜色的标题
function printHeader() {
  console.log('\n' + colorText('='.repeat(60), 'cyan'));
  console.log(colorText('                     LLMs Code 交互式 CLI', 'cyan'));
  console.log(colorText('='.repeat(60), 'cyan') + '\n');
}

// 打印帮助信息
function printHelp() {
  console.log(colorText('可用命令:', 'yellow'));
  console.log(`  ${colorText('/help', 'green')} - 显示帮助信息`);
  console.log(`  ${colorText('/models', 'green')} - 显示可用模型`);
  console.log(`  ${colorText('/model <模型名称>', 'green')} - 切换到指定模型`);
  console.log(`  ${colorText('/clear', 'green')} - 清除屏幕`);
  console.log(`  ${colorText('/exit', 'green')} - 退出程序`);
  console.log(`  ${colorText('<其他输入>', 'green')} - 发送到当前选择的模型\n`);
}

// 简单的加载动画
function startSpinner(message) {
  const frames = ['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏'];
  let i = 0;
  
  process.stdout.write(`${message} `);
  
  return setInterval(() => {
    process.stdout.write(`\r${message} ${frames[i++ % frames.length]}`);
  }, 80);
}

function stopSpinner() {
  process.stdout.write('\r\x1b[K'); // 清除当前行
}

// 主函数
async function main() {
  try {
    printHeader();
    console.log(colorText('正在初始化 LLMs Code...', 'yellow'));
    
    // 初始化适配器管理器
    const adapterManager = AdapterManager.getInstance();
    await adapterManager.initialize();
    
    // 获取可用模型
    const availableModels = adapterManager.getAvailableModels();
    
    if (availableModels.length === 0) {
      console.log(colorText('错误: 没有找到可用的模型配置。', 'red'));
      console.log(colorText('请确保 ~/.config/llms-code/config.yaml 文件存在并包含有效的模型配置。', 'yellow'));
      process.exit(1);
    }
    
    // 创建内容生成器，使用第一个可用模型
    const currentModel = availableModels[0].name;
    const generator = new AdapterContentGenerator(currentModel);
    await generator.initialize();
    
    console.log(colorText('初始化完成!', 'green'));
    console.log(colorText(`当前模型: ${colorText(currentModel, 'cyan')}`, 'yellow'));
    printHelp();
    
    // 交互循环
    while (true) {
      const input = await rl.question(colorText('> ', 'green'));
      
      // 处理命令
      if (input.startsWith('/')) {
        const command = input.split(' ')[0].toLowerCase();
        const args = input.substring(command.length).trim();
        
        switch (command) {
          case '/help':
            printHelp();
            break;
            
          case '/models':
            console.log(colorText('可用模型:', 'yellow'));
            availableModels.forEach(model => {
              const isCurrent = model.name === generator.getCurrentModel();
              console.log(`  ${isCurrent ? colorText('*', 'green') : ' '} ${colorText(model.name, 'cyan')} (${model.provider})`);
            });
            console.log('');
            break;
            
          case '/model':
            if (!args) {
              console.log(colorText('错误: 请指定模型名称。使用 /models 查看可用模型。', 'red'));
              break;
            }
            
            const targetModel = availableModels.find(m => m.name.toLowerCase() === args.toLowerCase());
            if (!targetModel) {
              console.log(colorText(`错误: 找不到模型 "${args}"。使用 /models 查看可用模型。`, 'red'));
              break;
            }
            
            generator.setModel(targetModel.name);
            console.log(colorText(`已切换到模型: ${colorText(targetModel.name, 'cyan')}`, 'green'));
            break;
            
          case '/clear':
            console.clear();
            printHeader();
            console.log(colorText(`当前模型: ${colorText(generator.getCurrentModel(), 'cyan')}`, 'yellow'));
            break;
            
          case '/exit':
            console.log(colorText('再见!', 'yellow'));
            process.exit(0);
            break;
            
          default:
            console.log(colorText(`未知命令: ${command}。使用 /help 查看可用命令。`, 'red'));
        }
      } else if (input.trim()) {
        // 发送消息到模型
        const spinner = startSpinner('正在思考中...');
        
        try {
          const response = await generator.generateContent({
            model: generator.getCurrentModel(),
            contents: input,
          });
          
          stopSpinner();
          console.log(colorText('\n🤖 ', 'cyan') + response.text + '\n');
        } catch (error) {
          stopSpinner();
          console.error(colorText(`错误: ${error.message}`, 'red'));
        } finally {
          clearInterval(spinner);
        }
      }
    }
  } catch (error) {
    console.error(colorText(`发生错误: ${error.message}`, 'red'));
    process.exit(1);
  }
}

// 运行主函数
main(); 