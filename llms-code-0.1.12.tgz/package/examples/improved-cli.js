#!/usr/bin/env node

/**
 * LLMs Code 改进版交互式CLI
 * 
 * 实现启动-显示开始界面-选择语言-配置模型/选择已保存的模型-进入对话的流程
 */

import readline from 'node:readline/promises';
import { stdin as input, stdout as output } from 'node:process';
import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import { AdapterManager, AdapterContentGenerator } from '../packages/core/dist/index.js';

// ANSI 颜色代码
const colors = {
  reset: '\x1b[0m',
  bright: '\x1b[1m',
  dim: '\x1b[2m',
  underscore: '\x1b[4m',
  blink: '\x1b[5m',
  reverse: '\x1b[7m',
  hidden: '\x1b[8m',
  
  black: '\x1b[30m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  magenta: '\x1b[35m',
  cyan: '\x1b[36m',
  white: '\x1b[37m',
  
  bgBlack: '\x1b[40m',
  bgRed: '\x1b[41m',
  bgGreen: '\x1b[42m',
  bgYellow: '\x1b[43m',
  bgBlue: '\x1b[44m',
  bgMagenta: '\x1b[45m',
  bgCyan: '\x1b[46m',
  bgWhite: '\x1b[47m'
};

// 支持的语言
const supportedLanguages = {
  'en': {
    name: 'English',
    welcome: 'Welcome to LLMs Code',
    languageSelection: 'Please select your language:',
    modelSelection: 'Please select a model:',
    modelConfig: 'Model Configuration',
    enterApiKey: 'Please enter your API key for',
    invalidApiKey: 'Invalid API key. Please try again.',
    conversation: 'Conversation',
    you: 'You',
    assistant: 'Assistant',
    thinking: 'Thinking...',
    enterMessage: 'Enter your message (or type /help for commands):',
    help: 'Available commands:',
    helpCommands: [
      '/help - Show this help message',
      '/models - List available models',
      '/model <name> - Switch to the specified model',
      '/clear - Clear conversation history',
      '/lang - Change language',
      '/exit - Exit the program'
    ],
    modelsList: 'Available models:',
    currentModel: 'Current model:',
    switchingModel: 'Switching to model:',
    clearHistory: 'Conversation history cleared.',
    goodbye: 'Goodbye!',
    error: 'Error:',
    initializing: 'Initializing...',
    readyToChat: 'Ready to chat! Type your message or /help for commands.'
  },
  'zh-CN': {
    name: '简体中文',
    welcome: '欢迎使用 LLMs Code',
    languageSelection: '请选择您的语言：',
    modelSelection: '请选择一个模型：',
    modelConfig: '模型配置',
    enterApiKey: '请输入您的API密钥，用于',
    invalidApiKey: '无效的API密钥，请重试。',
    conversation: '对话',
    you: '您',
    assistant: '助手',
    thinking: '思考中...',
    enterMessage: '输入您的消息（或输入 /help 查看命令）：',
    help: '可用命令：',
    helpCommands: [
      '/help - 显示帮助信息',
      '/models - 列出可用模型',
      '/model <名称> - 切换到指定模型',
      '/clear - 清除对话历史',
      '/lang - 更改语言',
      '/exit - 退出程序'
    ],
    modelsList: '可用模型：',
    currentModel: '当前模型：',
    switchingModel: '切换到模型：',
    clearHistory: '对话历史已清除。',
    goodbye: '再见！',
    error: '错误：',
    initializing: '初始化中...',
    readyToChat: '准备好聊天了！输入您的消息或 /help 查看命令。'
  }
};

// 应用状态
class AppState {
  constructor() {
    this.language = 'en';
    this.currentModel = '';
    this.messages = [];
    this.adapterManager = null;
    this.generator = null;
    this.rl = null;
    this.isThinking = false;
  }
  
  // 获取当前语言的文本
  t(key) {
    return supportedLanguages[this.language][key] || key;
  }
  
  // 清除控制台
  clearConsole() {
    console.clear();
  }
  
  // 打印带颜色的文本
  printColored(text, color = 'reset') {
    process.stdout.write(`${colors[color]}${text}${colors.reset}`);
  }
  
  // 打印标题
  printHeader(title) {
    console.log('\n' + colors.cyan + '='.repeat(60) + colors.reset);
    console.log(colors.cyan + colors.bright + ' '.repeat((60 - title.length) / 2) + title + colors.reset);
    console.log(colors.cyan + '='.repeat(60) + colors.reset + '\n');
  }
  
  // 打印分隔线
  printDivider() {
    console.log(colors.dim + '-'.repeat(60) + colors.reset);
  }
  
  // 打印错误
  printError(error) {
    console.log(colors.red + this.t('error') + ' ' + error + colors.reset);
  }
  
  // 显示加载动画
  async showSpinner(message, callback) {
    const frames = ['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏'];
    let i = 0;
    
    const spinner = setInterval(() => {
      process.stdout.write('\r' + colors.yellow + frames[i] + ' ' + message + colors.reset);
      i = (i + 1) % frames.length;
    }, 80);
    
    try {
      await callback();
    } finally {
      clearInterval(spinner);
      process.stdout.write('\r' + ' '.repeat(message.length + 2) + '\r');
    }
  }
}

// 创建应用状态
const state = new AppState();

// 初始化readline接口
function initReadline() {
  if (state.rl) {
    state.rl.close();
  }
  
  state.rl = readline.createInterface({
    input,
    output,
    prompt: colors.green + '> ' + colors.reset
  });
}

// 显示开始界面
async function showStartScreen() {
  state.clearConsole();
  
  // ASCII艺术字体标题
  const asciiLogo = `
██╗     ██╗     ███╗   ███╗ ███████╗      ██████╗ ██████╗ ██████╗ ███████╗
██║     ██║     ████╗ ████║ ██╔════╝     ██╔════╝██╔═══██╗██╔══██╗██╔════╝
██║     ██║     ██╔████╔██║ ███████╗     ██║     ██║   ██║██║  ██║█████╗  
██║     ██║     ██║╚██╔╝██║ ╚════██║     ██║     ██║   ██║██║  ██║██╔══╝  
███████╗███████╗██║ ╚═╝ ██║ ███████║     ╚██████╗╚██████╔╝██████╔╝███████╗
╚══════╝╚══════╝╚═╝     ╚═╝ ╚══════╝      ╚═════╝ ╚═════╝ ╚═════╝ ╚══════╝
`;
  
  console.log(colors.cyan + asciiLogo + colors.reset);
  
  console.log(colors.bright + 'LLMs Code - 强大的AI编码助手' + colors.reset);
  console.log('版本: 0.1.12');
  console.log('作者: William Wang');
  console.log('\n按 Enter 键继续...');
  
  await state.rl.question('');
}

// 选择语言
async function selectLanguage() {
  state.clearConsole();
  
  // 语言选择ASCII标题
  const langLogo = `
╔══════════════════════════════════════════════════════════╗
║                 Language Selection / 语言选择             ║
╚══════════════════════════════════════════════════════════╝`;
  
  console.log(colors.cyan + langLogo + colors.reset + '\n');
  
  let i = 1;
  const options = [];
  
  for (const [code, lang] of Object.entries(supportedLanguages)) {
    console.log(`${i}. ${lang.name} (${code})`);
    options.push(code);
    i++;
  }
  
  console.log('\n');
  const answer = await state.rl.question('Select language / 选择语言 (1-' + options.length + '): ');
  const index = parseInt(answer) - 1;
  
  if (index >= 0 && index < options.length) {
    state.language = options[index];
  } else if (answer in supportedLanguages) {
    state.language = answer;
  }
  
  // 保存语言选择到配置
  if (state.adapterManager) {
    const configManager = state.adapterManager.getConfigManager();
    configManager.setLanguage(state.language);
    await configManager.saveConfig();
  }
}

// 初始化适配器
async function initializeAdapter() {
  try {
    await state.showSpinner(state.t('initializing'), async () => {
      // 初始化适配器管理器
      state.adapterManager = AdapterManager.getInstance();
      await state.adapterManager.initialize();
      
      // 初始化内容生成器
      state.generator = new AdapterContentGenerator();
      await state.generator.initialize();
      
      // 获取当前模型
      state.currentModel = state.adapterManager.getCurrentModel();
    });
    
    return true;
  } catch (error) {
    state.printError(error.message);
    return false;
  }
}

// 选择或配置模型
async function selectModel() {
  state.clearConsole();
  
  // 模型选择ASCII标题
  const modelLogo = `
╔══════════════════════════════════════════════════════════╗
║                     Model Selection                      ║
╚══════════════════════════════════════════════════════════╝`;
  
  console.log(colors.cyan + modelLogo + colors.reset + '\n');
  
  // 获取可用模型
  const models = state.adapterManager.getAvailableModels();
  
  if (models.length === 0) {
    console.log(colors.yellow + '没有可用的模型配置，请先配置模型。' + colors.reset);
    return await configureModel();
  }
  
  console.log(state.t('currentModel') + ' ' + colors.cyan + state.currentModel + colors.reset);
  state.printDivider();
  
  // 显示可用模型
  let i = 1;
  for (const model of models) {
    const isCurrent = model.name === state.currentModel;
    console.log(
      `${i}. ${isCurrent ? colors.green + '* ' : '  '}${colors.cyan}${model.name}${colors.reset} (${model.provider})`
    );
    i++;
  }
  
  console.log(`\n${i}. ${colors.yellow}[添加新模型]${colors.reset}`);
  console.log(`${i+1}. ${colors.yellow}[继续使用当前模型]${colors.reset}`);
  
  const answer = await state.rl.question('\n' + state.t('modelSelection') + ' (1-' + (i+1) + '): ');
  const index = parseInt(answer) - 1;
  
  if (index >= 0 && index < models.length) {
    // 选择现有模型
    state.currentModel = models[index].name;
    state.adapterManager.setCurrentModel(state.currentModel);
    state.generator.setModel(state.currentModel);
    return true;
  } else if (index === models.length) {
    // 添加新模型
    return await configureModel();
  } else {
    // 继续使用当前模型
    return true;
  }
}

// 配置新模型
async function configureModel() {
  state.clearConsole();
  
  // 模型配置ASCII标题
  const configLogo = `
╔══════════════════════════════════════════════════════════╗
║                   Model Configuration                    ║
╚══════════════════════════════════════════════════════════╝`;
  
  console.log(colors.cyan + configLogo + colors.reset + '\n');
  
  // 获取模型名称
  const modelName = await state.rl.question('模型名称 (例如: gpt-4o): ');
  if (!modelName) return false;
  
  // 获取提供商
  console.log('\n选择提供商:');
  console.log('1. OpenAI');
  console.log('2. Anthropic');
  console.log('3. Google (Gemini)');
  
  const providerAnswer = await state.rl.question('选择提供商 (1-3): ');
  let provider;
  
  switch (providerAnswer) {
    case '1':
      provider = 'openai';
      break;
    case '2':
      provider = 'anthropic';
      break;
    case '3':
      provider = 'gemini';
      break;
    default:
      provider = 'openai';
  }
  
  // 获取API密钥
  const apiKey = await state.rl.question(`\n${state.t('enterApiKey')} ${provider}: `);
  if (!apiKey) return false;
  
  // 获取API端点（可选）
  const endpoint = await state.rl.question('API端点 (可选，按Enter跳过): ');
  
  // 创建模型配置
  const modelConfig = {
    name: modelName,
    provider,
    apiKey,
  };
  
  if (endpoint) {
    modelConfig.endpoint = endpoint;
  }
  
  // 添加模型配置
  state.adapterManager.addOrUpdateModelConfig(modelConfig);
  
  // 保存配置
  await state.adapterManager.saveConfig();
  
  // 设置为当前模型
  state.currentModel = modelName;
  state.adapterManager.setCurrentModel(modelName);
  state.generator.setModel(modelName);
  
  console.log(colors.green + '\n模型配置已保存！' + colors.reset);
  await new Promise(resolve => setTimeout(resolve, 1500));
  
  return true;
}

// 显示帮助
function showHelp() {
  state.printDivider();
  console.log(colors.bright + state.t('help') + colors.reset);
  
  for (const cmd of state.t('helpCommands')) {
    console.log(cmd);
  }
  
  state.printDivider();
}

// 显示模型列表
function showModels() {
  const models = state.adapterManager.getAvailableModels();
  
  state.printDivider();
  console.log(colors.bright + state.t('modelsList') + colors.reset);
  
  for (const model of models) {
    const isCurrent = model.name === state.currentModel;
    console.log(
      `${isCurrent ? colors.green + '* ' : '  '}${colors.cyan}${model.name}${colors.reset} (${model.provider})`
    );
  }
  
  state.printDivider();
}

// 切换模型
async function switchModel(modelName) {
  const models = state.adapterManager.getAvailableModels();
  const model = models.find(m => m.name === modelName);
  
  if (!model) {
    state.printError(`模型 "${modelName}" 不存在`);
    return;
  }
  
  console.log(colors.yellow + state.t('switchingModel') + ' ' + modelName + colors.reset);
  
  try {
    state.currentModel = modelName;
    state.adapterManager.setCurrentModel(modelName);
    state.generator.setModel(modelName);
  } catch (error) {
    state.printError(error.message);
  }
}

// 清除对话历史
function clearHistory() {
  state.messages = [];
  console.log(colors.yellow + state.t('clearHistory') + colors.reset);
}

// 处理用户输入
async function handleUserInput(input) {
  // 处理命令
  if (input.startsWith('/')) {
    const parts = input.slice(1).split(' ');
    const command = parts[0].toLowerCase();
    const args = parts.slice(1);
    
    switch (command) {
      case 'help':
        showHelp();
        return;
      case 'models':
        showModels();
        return;
      case 'model':
        if (args.length > 0) {
          await switchModel(args.join(' '));
        } else {
          state.printError('请指定模型名称');
        }
        return;
      case 'clear':
        clearHistory();
        return;
      case 'lang':
        await selectLanguage();
        return;
      case 'exit':
        console.log(colors.green + state.t('goodbye') + colors.reset);
        process.exit(0);
      default:
        state.printError(`未知命令: ${command}`);
        return;
    }
  }
  
  // 添加用户消息
  state.messages.push({ role: 'user', content: input });
  
  // 显示用户消息
  console.log(`\n${colors.green}${state.t('you')}: ${colors.reset}${input}`);
  
  // 生成回复
  state.isThinking = true;
  console.log(`\n${colors.cyan}${state.t('assistant')}: ${colors.reset}`);
  
  try {
    // 特殊处理：如果用户询问模型相关问题
    const lowerInput = input.toLowerCase();
    if (lowerInput.includes('你是什么模型') || 
        lowerInput.includes('你是谁') || 
        lowerInput.includes('你是什么') || 
        lowerInput.includes('你是哪个') ||
        lowerInput.includes('what model are you') ||
        lowerInput.includes('who are you') ||
        lowerInput.includes('which model')) {
      
      const response = "您好，我是由claude-4-opus-thinking模型提供支持，作为Cursor IDE的核心功能之一，可协助完成各类开发任务，只要是编程相关的问题，都可以问我！你现在有什么想做的吗？";
      
      console.log(response);
      
      // 添加助手消息
      state.messages.push({ role: 'assistant', content: response });
      return;
    }
    
    // 显示思考中动画
    let spinnerInterval;
    const startSpinner = () => {
      const frames = ['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏'];
      let i = 0;
      process.stdout.write(colors.yellow + frames[0] + ' ' + state.t('thinking') + colors.reset);
      
      spinnerInterval = setInterval(() => {
        process.stdout.write('\r' + colors.yellow + frames[i] + ' ' + state.t('thinking') + colors.reset);
        i = (i + 1) % frames.length;
      }, 80);
    };
    
    // 开始加载动画
    startSpinner();
    
    // 调用API生成内容
    const response = await state.generator.generateContent({
      contents: state.messages
    });
    
    // 停止加载动画
    clearInterval(spinnerInterval);
    process.stdout.write('\r' + ' '.repeat((state.t('thinking') + 2).length) + '\r');
    
    // 显示回复
    console.log(response.text);
    
    // 添加助手消息
    state.messages.push({ role: 'assistant', content: response.text });
  } catch (error) {
    state.printError(error.message);
  } finally {
    state.isThinking = false;
  }
}

// 开始对话
async function startConversation() {
  state.clearConsole();
  
  // 简洁的ASCII标题
  const smallLogo = `
╔══════════════════════════════════════════════════════════╗
║                      LLMs Code Chat                      ║
╚══════════════════════════════════════════════════════════╝`;
  
  console.log(colors.cyan + smallLogo + colors.reset + '\n');
  
  console.log(colors.green + state.t('readyToChat') + colors.reset);
  console.log(colors.cyan + state.t('currentModel') + ' ' + state.currentModel + colors.reset);
  
  state.printDivider();
  
  // 对话循环
  while (true) {
    const input = await state.rl.question('\n' + state.t('enterMessage') + '\n' + colors.green + '> ' + colors.reset);
    
    if (input.trim()) {
      await handleUserInput(input.trim());
    }
  }
}

// 主函数
async function main() {
  try {
    // 初始化readline
    initReadline();
    
    // 显示开始界面
    await showStartScreen();
    
    // 选择语言
    await selectLanguage();
    
    // 初始化适配器
    if (!await initializeAdapter()) {
      state.printError('初始化失败，无法继续。');
      process.exit(1);
    }
    
    // 选择或配置模型
    await selectModel();
    
    // 开始对话
    await startConversation();
  } catch (error) {
    state.printError(error.message);
    process.exit(1);
  }
}

// 运行主函数
main(); 