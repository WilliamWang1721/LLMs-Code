#!/usr/bin/env node

/**
 * LLMs Code 配置设置脚本
 * 
 * 此脚本帮助用户设置 LLMs Code 的配置，包括 API 密钥和默认模型。
 * 使用方法：
 *   node setup-config.js
 */

import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import readline from 'node:readline/promises';
import { stdin as input, stdout as output } from 'node:process';
import yaml from 'js-yaml';

// ANSI 颜色代码
const colors = {
  reset: '\x1b[0m',
  bright: '\x1b[1m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  cyan: '\x1b[36m',
};

// 打印带颜色的文本
function colorText(text, color) {
  return `${colors[color]}${text}${colors.reset}`;
}

// 打印带颜色的标题
function printHeader() {
  console.log('\n' + colorText('='.repeat(60), 'cyan'));
  console.log(colorText('                LLMs Code 配置设置向导', 'cyan'));
  console.log(colorText('='.repeat(60), 'cyan') + '\n');
}

// 主函数
async function main() {
  const rl = readline.createInterface({ input, output });
  
  try {
    printHeader();
    console.log(colorText('欢迎使用 LLMs Code 配置设置向导！', 'green'));
    console.log('此向导将帮助您设置 LLMs Code 的配置，包括 API 密钥和默认模型。');
    console.log('配置文件将保存在 ~/.config/llms-code/config.yaml\n');
    
    // 创建配置目录
    const configDir = path.join(os.homedir(), '.config', 'llms-code');
    await fs.mkdir(configDir, { recursive: true });
    
    // 检查是否已存在配置文件
    const configPath = path.join(configDir, 'config.yaml');
    let existingConfig = {};
    
    try {
      const configContent = await fs.readFile(configPath, 'utf-8');
      existingConfig = yaml.load(configContent) || {};
      console.log(colorText('检测到已有配置文件。', 'yellow'));
      const overwrite = await rl.question(colorText('是否要覆盖现有配置？(y/n) ', 'yellow'));
      
      if (overwrite.toLowerCase() !== 'y') {
        console.log(colorText('操作已取消。', 'yellow'));
        process.exit(0);
      }
    } catch (error) {
      // 文件不存在，创建新配置
    }
    
    // 设置语言
    const language = await rl.question(colorText('请选择界面语言 (en/zh-CN) [默认: zh-CN]: ', 'green'));
    
    // 设置默认模型
    console.log('\n' + colorText('请选择默认模型:', 'green'));
    console.log('1. OpenAI GPT-4o');
    console.log('2. Anthropic Claude 3 Opus');
    console.log('3. Google Gemini 1.5 Pro');
    
    const modelChoice = await rl.question(colorText('请输入选项 (1-3) [默认: 1]: ', 'green'));
    
    let defaultModel;
    switch (modelChoice) {
      case '2':
        defaultModel = 'claude-3-opus';
        break;
      case '3':
        defaultModel = 'gemini-1.5-pro';
        break;
      default:
        defaultModel = 'gpt-4o';
    }
    
    // 设置 API 密钥
    console.log('\n' + colorText('请设置 API 密钥:', 'green'));
    
    // OpenAI API 密钥
    const openaiKey = await rl.question(colorText('OpenAI API 密钥 (留空则跳过): ', 'green'));
    
    // Anthropic API 密钥
    const anthropicKey = await rl.question(colorText('Anthropic API 密钥 (留空则跳过): ', 'green'));
    
    // Google API 密钥
    const googleKey = await rl.question(colorText('Google API 密钥 (留空则跳过): ', 'green'));
    
    // 创建配置对象
    const config = {
      language: language || 'zh-CN',
      default_model: defaultModel,
      models: []
    };
    
    // 添加模型配置
    if (openaiKey) {
      config.models.push({
        name: 'gpt-4o',
        provider: 'openai',
        api_key: `env:OPENAI_API_KEY`
      });
      
      // 设置环境变量
      process.env.OPENAI_API_KEY = openaiKey;
    }
    
    if (anthropicKey) {
      config.models.push({
        name: 'claude-3-opus',
        provider: 'anthropic',
        api_key: `env:ANTHROPIC_API_KEY`
      });
      
      // 设置环境变量
      process.env.ANTHROPIC_API_KEY = anthropicKey;
    }
    
    if (googleKey) {
      config.models.push({
        name: 'gemini-1.5-pro',
        provider: 'gemini',
        api_key: `env:GEMINI_API_KEY`
      });
      
      // 设置环境变量
      process.env.GEMINI_API_KEY = googleKey;
    }
    
    // 保存配置文件
    const yamlContent = yaml.dump(config, {
      indent: 2,
      lineWidth: 100,
    });
    
    await fs.writeFile(configPath, yamlContent, 'utf-8');
    
    console.log('\n' + colorText('配置已保存到 ' + configPath, 'green'));
    
    // 生成环境变量设置脚本
    const envPath = path.join(configDir, 'env.sh');
    let envContent = '#!/bin/bash\n\n# LLMs Code 环境变量设置脚本\n\n';
    
    if (openaiKey) {
      envContent += `export OPENAI_API_KEY="${openaiKey}"\n`;
    }
    
    if (anthropicKey) {
      envContent += `export ANTHROPIC_API_KEY="${anthropicKey}"\n`;
    }
    
    if (googleKey) {
      envContent += `export GEMINI_API_KEY="${googleKey}"\n`;
    }
    
    await fs.writeFile(envPath, envContent, 'utf-8');
    await fs.chmod(envPath, 0o755);
    
    console.log(colorText('环境变量设置脚本已保存到 ' + envPath, 'green'));
    console.log(colorText('您可以通过运行以下命令来设置环境变量:', 'yellow'));
    console.log(colorText(`  source ${envPath}`, 'cyan'));
    
    console.log('\n' + colorText('设置完成！现在您可以使用 LLMs Code 了。', 'green'));
    console.log(colorText('尝试运行: node interactive-cli.js', 'cyan'));
  } catch (error) {
    console.error(colorText(`发生错误: ${error.message}`, 'red'));
    process.exit(1);
  } finally {
    rl.close();
  }
}

// 运行主函数
main(); 